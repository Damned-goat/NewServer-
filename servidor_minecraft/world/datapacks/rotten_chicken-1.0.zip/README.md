# Rotten chicken

What tastes like chicken? Rotten flesh is what!

## Features

**Rotten chicken** is a Minecraft datapack that lets you cook _rotten flesh_ to produce delicious _cooked chicken_.

The noxious flesh can be cooked on the campfire, furnace, and smoker, with the usual effect on cooking time. Cooking one flesh stores 0.1 xp in the furnace/smoker. 

## Rationale

The _rotten flesh_ in Minecraft is essentially a junk item with no real use. Even as a villager trading item, it is weak, as it requires a lot of clicks to get anywhere.

Many datapacks propose to smelt the _rotten flesh_ into _leather_. This is however in my opinion overpowered, and removes the incentive to have a cow or zogglin farming operation.

This datapack intends to provide a balanced, yet useful alternative. 

